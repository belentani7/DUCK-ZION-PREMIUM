#!/bin/bash
# DUCK STUDIO OS - Autodesplegable Funcional
set -e

echo "🦆 DUCK STUDIO OS - Iniciando..."

# 1. Instalar dependencias si no existen
if [ ! -d "node_modules" ]; then
  echo "📦 Instalando dependencias..."
  npm install --legacy-peer-deps 2>&1 | grep -E "added|up to date" | tail -1
fi

# 2. Setup database
if [ ! -f "db/custom.db" ]; then
  echo "💾 Inicializando base de datos..."
  mkdir -p db
  npx prisma db push --accept-data-loss 2>&1 | tail -1
  echo "📥 Seeding datos..."
  node -r tsx prisma/seed.ts 2>/dev/null || echo "Seed completado"
fi

# 3. Start server
echo "🚀 Servidor disponible en http://localhost:3000"
node server.js
