# 🦆 DUCK STUDIO OS — RnF

**Sistema Operacional de Estudio Musical Autodesplegable**

---

## ⚡ Inicio Rápido

### Linux/Mac
```bash
tar -xzf DUCK-STUDIO-OS.tar.gz
cd DUCK-STUDIO-OS
bash RUN.sh
# → http://localhost:3000
```

### Windows
```cmd
tar -xzf DUCK-STUDIO-OS.tar.gz
cd DUCK-STUDIO-OS
start-windows.bat
# → http://localhost:3000
```

### Docker
```bash
docker-compose up
# → http://localhost:3000
```

---

## 📦 Contenido

- **src/** — Código completo (125 archivos TS/TSX)
- **prisma/** — Schema + seed (13 modelos de datos)
- **server.js** — Servidor HTTP autodesplegable
- **db/custom.db** — Base de datos SQLite
- **package.json** — Dependencias (290 paquetes)

---

## 🎯 Características

✅ **Dashboard real** — 8 KPIs en vivo
✅ **CRM completo** — Gestión de clientes (RBAC)
✅ **Proyectos** — 14 estados + versiones + comentarios
✅ **Automatización** — Motor integrado en 4 flujos
✅ **Cadeias** — 5 presets de procesamiento seeded
✅ **QC Checklist** — 20 items verificables (persistencia confirmada)
✅ **Herramientas Audio** — Afinador, Espectro, Loudness
✅ **Waveform Player** — Reproducción + comentarios por timestamp
✅ **Facturas** — PDF con VAT automático + impresión
✅ **Onboarding** — Wizard 5 pasos (cliente + proyecto)
✅ **Calendario** — Deadlines, invoices, tasks
✅ **Analytics** — Gráficos en tiempo real (recharts)
✅ **DAW Bridge** — Abstracción de 7 DAWs
✅ **Asistente IA** — Duck flotante con contexto operacional
✅ **Memory Management** — Persistencia por scope

---

## 🗄️ Base de Datos

**Esquema Prisma (13 modelos)**:
- User, Client, Project, Version, Task, Activity
- Automation, AutomationRun, ProcessingChain
- Invoice, InvoiceItem, QcItem, PluginPack
- Capabilities, Memory

**Seed automático**: 
- 5 clientes demo (Ana Silva, João, Pedro, etc)
- 3 proyectos en diferentes estados
- 20 items QC (6 categorías)
- 5 automatizaciones ejemplo
- 5 cadeias de procesamiento

---

## 🔌 API Endpoints

```
GET  /api/session           → Usuario actual + rol
GET  /api/stats             → Dashboard KPIs
GET  /api/projects          → Lista de proyectos
GET  /api/projects/:id      → Detalle + versiones
POST /api/projects/:id/approve  → Aprobar versión
POST /api/automations/test  → Trigger manual
GET  /api/analytics         → Gráficos + trends
GET  /api/calendar          → Eventos del mes
GET  /api/memory            → Contexto IA por scope
POST /api/cron/checks       → Scheduled checks (token-protected)
```

---

## 🎨 Interfaz

**Tema**: Verde Neón (dark-first, estilo Google UX)
- Colores: oklch() con precisión perceptual
- Animaciones: duck-fade-in, duck-scale-in, duck-pulse
- Asistente flotante: rostro redondo humanizado
- Pantalla de carga: shader osciloscopio + frases PT-BR

---

## 🚀 Deployment

### Producción
```bash
# Build
npm run build
# Start
NODE_ENV=production npm start
```

### Contenedor
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm install --legacy-peer-deps
RUN npx prisma db push --accept-data-loss
CMD ["node", "server.js"]
```

---

## 🔧 Configuración

**Variables de entorno**:
```bash
PORT=3000                    # Puerto HTTP
DATABASE_URL=file:./db/custom.db  # SQLite
NODE_ENV=production          # dev/production
```

**Modificar tema**:
Editar `src/app/globals.css` (variables --neon, --primary, etc)

---

## 📊 Roles (RBAC)

- **OWNER**: Acceso completo (Duck)
- **ENGINEER**: Gestión de proyectos (Pedro)
- **COLLABORATOR**: Edición limitada
- **CLIENT**: Vista de propios proyectos + facturas

---

## ✅ Verificación

```bash
# Health check
curl http://localhost:3000/api/session

# Stats
curl http://localhost:3000/api/stats

# Projects
curl http://localhost:3000/api/projects
```

---

## 🐛 Troubleshooting

**Puerto 3000 ya en uso**:
```bash
PORT=8080 npm start
```

**Base de datos corrupta**:
```bash
rm db/custom.db
npx prisma db push --accept-data-loss
npm run seed
```

**Módulos faltantes**:
```bash
npm install --legacy-peer-deps
```

---

## 📝 Notas

- **No requiere API keys externas** — Completamente offline
- **Mejorable con servicios** — Preparado para OpenRouter, LiteLLM, n8n
- **Datos DEMO** — Seed contiene 8 clientes + 3 proyectos reales
- **Auditoría completa** — Cada operación registra actor, timestamp, cambios
- **Cron autónomo** — webDevReview cada 15 min (en ambiente de desarrollo)

---

## 📞 Soporte

Para problemas, verificar:
1. Node.js v18+
2. SQLite disponible
3. Puerto 3000 libre
4. Permisos de lectura/escritura en `db/`

---

**DUCK STUDIO OS v0.2.1** — *Ritmo & Frequência*
