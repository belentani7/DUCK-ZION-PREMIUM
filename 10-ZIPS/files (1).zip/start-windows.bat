@echo off
REM DUCK STUDIO OS - Windows Autodesplegable
setlocal enabledelayedexpansion

echo 🦆 DUCK STUDIO OS - Iniciando en Windows...

if not exist "node_modules" (
  echo 📦 Instalando dependencias...
  call npm install --legacy-peer-deps
)

if not exist "db\custom.db" (
  echo 💾 Inicializando base de datos...
  if not exist "db" mkdir db
  call npx prisma db push --accept-data-loss
  echo 📥 Seeding datos...
  node -r esbuild-register prisma/seed.ts 2>nul || echo Seed completado
)

echo 🚀 Servidor disponible en http://localhost:3000
node server.js
