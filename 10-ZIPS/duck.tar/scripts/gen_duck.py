#!/usr/bin/env python3
"""Gera Duck Studio Toolkit - A Gema #1 completo"""

parts = []

def w(s): parts.append(s)

w(r'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Duck Studio Toolkit - A Gema #1 | Masterização Belentani</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
:root{--ng:#00ff88;--ng-dim:#00cc6a;--ng-br:#39ff14;--ng-dk:#004d29;--ng-gl:rgba(0,255,136,.4);--ng-sb:rgba(0,255,136,.1);--bg1:#0a0f0d;--bg2:#0d1512;--bg3:#111d19;--card:rgba(13,25,20,.6);--gls:rgba(0,255,136,.03);--gb:rgba(0,255,136,.15);--gbh:rgba(0,255,136,.4);--t1:#e0f5ea;--t2:#8fb8a0;--t3:#4a7a62;--dng:#ff3366;--wrn:#ffaa00;--fd:'Orbitron',sans-serif;--fb:'Rajdhani',sans-serif;--fm:'Share Tech Mono',monospace;--sw:72px;--se:240px;--th:56px;--tf:.2s cubic-bezier(.4,0,.2,1);--tm:.4s cubic-bezier(.4,0,.2,1)}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:var(--fb);background:var(--bg1);color:var(--t1);overflow:hidden;height:100vh;width:100vw;user-select:none}
''')

w(r'''/* LOADING SCREEN */
#ld{position:fixed;inset:0;background:var(--bg1);z-index:10000;display:flex;flex-direction:column;align-items:center;justify-content:center;transition:opacity .8s,visibility .8s}
#ld.hid{opacity:0;visibility:hidden;pointer-events:none}
.ld-lo{font-family:var(--fd);font-size:2.5rem;font-weight:900;color:var(--ng);text-shadow:0 0 20px var(--ng-gl),0 0 40px var(--ng-gl),0 0 80px var(--ng-gl);letter-spacing:8px;margin-bottom:8px;animation:ldp 1.5s ease-in-out infinite}
.ld-sb{font-family:var(--fm);font-size:.85rem;color:var(--t2);letter-spacing:4px;margin-bottom:40px}
.ld-bc{width:300px;height:3px;background:var(--bg3);border-radius:2px;overflow:hidden}
.ld-br{height:100%;width:0;background:linear-gradient(90deg,var(--ng-dk),var(--ng),var(--ng-br));border-radius:2px;box-shadow:0 0 10px var(--ng-gl);transition:width .3s}
.ld-tx{font-family:var(--fm);font-size:.7rem;color:var(--t3);margin-top:16px;letter-spacing:2px}
.ld-vr{position:absolute;bottom:30px;font-family:var(--fm);font-size:.65rem;color:var(--t3);letter-spacing:3px}
@keyframes ldp{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.7;transform:scale(.98)}}
''')

w(r'''/* BACKGROUND */
#bgc{position:fixed;inset:0;z-index:0;pointer-events:none}
/* APP */
#app{display:flex;height:100vh;width:100vw;position:relative;z-index:1;opacity:0;transition:opacity .6s}
#app.vis{opacity:1}
''')

w(r'''/* SIDEBAR */
.sb{width:var(--sw);height:100vh;background:var(--gls);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-right:1px solid var(--gb);display:flex;flex-direction:column;align-items:center;padding:12px 0;transition:width var(--tm);position:relative;z-index:100;overflow:hidden;flex-shrink:0}
.sb:hover{width:var(--se)}
.sb-lo{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--ng-dk),var(--bg3));border:1px solid var(--gb);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:900;font-size:1.1rem;color:var(--ng);text-shadow:0 0 10px var(--ng-gl);margin-bottom:20px;cursor:pointer;transition:all var(--tf);flex-shrink:0}
.sb-lo:hover{border-color:var(--ng);box-shadow:0 0 20px var(--ng-gl)}
.sb-nv{display:flex;flex-direction:column;gap:4px;width:100%;padding:0 12px;flex:1}
.ni{display:flex;align-items:center;gap:14px;padding:12px;border-radius:10px;cursor:pointer;transition:all var(--tf);position:relative;white-space:nowrap;overflow:hidden}
.ni:hover{background:var(--ng-sb)}
.ni.ac{background:rgba(0,255,136,.12);border:1px solid var(--gb)}
.ni.ac::before{content:'';position:absolute;left:-12px;top:50%;transform:translateY(-50%);width:3px;height:24px;background:var(--ng);border-radius:0 3px 3px 0;box-shadow:0 0 10px var(--ng-gl)}
.ni-ic{width:20px;height:20px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1.1rem}
.ni-lb{font-family:var(--fb);font-size:.85rem;font-weight:500;color:var(--t2);opacity:0;transition:opacity var(--tm)}
.sb:hover .ni-lb{opacity:1}
.ni.ac .ni-lb,.ni:hover .ni-lb{color:var(--t1)}
.sb-bt{padding:0 12px;width:100%}
''')

w(r'''/* MAIN & TOPBAR */
.mc{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0}
.tb{height:var(--th);display:flex;align-items:center;justify-content:space-between;padding:0 24px;background:var(--gls);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-bottom:1px solid var(--gb);flex-shrink:0}
.tb-t{font-family:var(--fd);font-size:.9rem;font-weight:600;letter-spacing:3px;color:var(--ng);text-transform:uppercase}
.tb-r{display:flex;align-items:center;gap:16px}
.tb-ck{font-family:var(--fm);font-size:.8rem;color:var(--t2)}
.tb-st{display:flex;align-items:center;gap:6px;font-family:var(--fm);font-size:.7rem;color:var(--ng)}
.sdot{width:6px;height:6px;border-radius:50%;background:var(--ng);box-shadow:0 0 8px var(--ng-gl);animation:sblk 2s ease-in-out infinite}
@keyframes sblk{0%,100%{opacity:1}50%{opacity:.3}}
''')

w(r'''/* CONTENT AREA */
.ca{flex:1;overflow-y:auto;overflow-x:hidden;padding:24px;position:relative}
.ca::-webkit-scrollbar{width:6px}
.ca::-webkit-scrollbar-track{background:transparent}
.ca::-webkit-scrollbar-thumb{background:var(--gb);border-radius:3px}
.pg{display:none;animation:pgi .5s ease forwards}
.pg.ac{display:block}
@keyframes pgi{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
''')

w(r'''/* GLASS CARD */
.gc{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--gb);border-radius:16px;padding:24px;margin-bottom:20px;transition:all var(--tm);position:relative;overflow:hidden}
.gc::before{content:'';position:absolute;top:0;left:0;width:100%;height:1px;background:linear-gradient(90deg,transparent,var(--ng-gl),transparent);opacity:0;transition:opacity var(--tm)}
.gc:hover{border-color:var(--gbh);box-shadow:0 8px 32px rgba(0,255,136,.08)}
.gc:hover::before{opacity:1}
.ch{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.ct{font-family:var(--fd);font-size:.8rem;font-weight:600;letter-spacing:2px;color:var(--ng);text-transform:uppercase}
''')

w(r'''/* GRIDS */
.g2{display:grid;grid-template-columns:repeat(2,1fr);gap:20px}
.g3{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
/* STAT CARDS */
.sc{background:var(--card);backdrop-filter:blur(12px);border:1px solid var(--gb);border-radius:14px;padding:20px;text-align:center;transition:all var(--tm);overflow:hidden}
.sc:hover{border-color:var(--gbh);transform:translateY(-4px);box-shadow:0 12px 40px rgba(0,255,136,.1)}
.sv{font-family:var(--fd);font-size:2rem;font-weight:800;color:var(--ng);text-shadow:0 0 20px var(--ng-gl);line-height:1.2}
.sl{font-family:var(--fb);font-size:.8rem;color:var(--t2);margin-top:4px;text-transform:uppercase;letter-spacing:1px}
''')

w(r'''/* BUTTONS */
.btn{font-family:var(--fb);font-weight:600;font-size:.85rem;padding:10px 24px;border-radius:8px;border:1px solid var(--gb);background:var(--gls);color:var(--t1);cursor:pointer;transition:all var(--tf);letter-spacing:1px;text-transform:uppercase;overflow:hidden}
.btn:hover{border-color:var(--ng);background:rgba(0,255,136,.1);color:var(--ng);box-shadow:0 0 20px rgba(0,255,136,.15)}
.btn-p{background:linear-gradient(135deg,var(--ng-dk),rgba(0,255,136,.2));border-color:var(--ng);color:var(--ng)}
.btn-p:hover{background:linear-gradient(135deg,rgba(0,255,136,.3),rgba(0,255,136,.4));box-shadow:0 0 30px rgba(0,255,136,.25)}
.btn-s{padding:6px 14px;font-size:.75rem}
/* INPUT */
.inp{font-family:var(--fm);font-size:.85rem;padding:10px 16px;border-radius:8px;border:1px solid var(--gb);background:rgba(0,0,0,.3);color:var(--t1);outline:none;transition:all var(--tf);width:100%}
.inp:focus{border-color:var(--ng);box-shadow:0 0 15px rgba(0,255,136,.15)}
.inp::placeholder{color:var(--t3)}
sel.inp,select.inp{appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12'%3E%3Cpath d='M6 8L1 3h10z' fill='%2300ff88'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:36px}
input[type=range]{-webkit-appearance:none;width:100%;height:4px;background:var(--bg3);border-radius:2px;outline:none}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:var(--ng);box-shadow:0 0 10px var(--ng-gl);cursor:pointer}
''')

w(r'''/* TUNER */
.tu-d{text-align:center;padding:30px 0}
.tu-n{font-family:var(--fd);font-size:6rem;font-weight:900;color:var(--ng);text-shadow:0 0 40px var(--ng-gl),0 0 80px var(--ng-gl);line-height:1;transition:all .15s}
.tu-f{font-family:var(--fm);font-size:1.4rem;color:var(--t2);margin-top:8px}
.tu-m{width:100%;max-width:400px;height:8px;background:var(--bg3);border-radius:4px;margin:20px auto 0;position:relative;overflow:hidden}
.tu-mc{position:absolute;left:50%;top:-4px;transform:translateX(-50%);width:2px;height:16px;background:var(--ng);box-shadow:0 0 8px var(--ng-gl)}
.tu-ind{position:absolute;top:0;left:50%;width:12px;height:100%;background:var(--ng);border-radius:4px;box-shadow:0 0 12px var(--ng-gl);transition:left .1s}
.tu-st{font-family:var(--fm);font-size:.8rem;color:var(--t3);margin-top:16px;letter-spacing:2px}
''')

w(r'''/* LOGO */
.lp{width:200px;height:200px;border-radius:20px;border:2px solid var(--gb);background:var(--bg1);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-family:var(--fd);font-size:3rem;font-weight:900;color:var(--ng);text-shadow:0 0 20px var(--ng-gl);transition:all var(--tm);overflow:hidden;position:relative}
.lp::after{content:'';position:absolute;inset:0;border-radius:18px;background:linear-gradient(135deg,transparent 40%,rgba(0,255,136,.05) 100%);pointer-events:none}
/* PLUGIN */
.pl-i{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border:1px solid var(--gb);border-radius:10px;background:var(--card);margin-bottom:8px;transition:all var(--tf)}
.pl-i:hover{border-color:var(--gbh);background:rgba(0,255,136,.04)}
.pl-n{font-family:var(--fb);font-weight:600;font-size:.9rem;color:var(--t1)}
.pl-t{font-family:var(--fm);font-size:.7rem;color:var(--t3);text-transform:uppercase;letter-spacing:1px}
.pl-b{font-family:var(--fm);font-size:.65rem;padding:3px 10px;border-radius:20px;border:1px solid;letter-spacing:1px}
.be{border-color:var(--ng);color:var(--ng);background:rgba(0,255,136,.08)}
.bp{border-color:#00ffd5;color:#00ffd5;background:rgba(0,255,213,.08)}
.bv{border-color:var(--wrn);color:var(--wrn);background:rgba(255,170,0,.08)}
''')

w(r'''/* TRACKS */
.trk{display:grid;grid-template-columns:40px 1fr 130px 90px 50px;align-items:center;gap:14px;padding:12px 16px;border:1px solid var(--gb);border-radius:10px;background:var(--card);margin-bottom:6px;transition:all var(--tf);cursor:pointer}
.trk:hover{border-color:var(--gbh);background:rgba(0,255,136,.04)}
.trk.pla{border-color:var(--ng);background:rgba(0,255,136,.08)}
.trk-n{font-family:var(--fm);font-size:.8rem;color:var(--t3);text-align:center}
.trk-i h4{font-family:var(--fb);font-weight:600;font-size:.9rem;color:var(--t1);margin-bottom:2px}
.trk-i span{font-family:var(--fm);font-size:.7rem;color:var(--t3)}
.trk-g{font-family:var(--fm);font-size:.7rem;padding:3px 10px;border-radius:20px;border:1px solid var(--gb);color:var(--t2);text-align:center}
.trk-bp{font-family:var(--fm);font-size:.75rem;color:var(--ng);text-align:center}
.trk-pb{width:32px;height:32px;border-radius:50%;border:1px solid var(--gb);background:transparent;color:var(--t2);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all var(--tf);font-size:.8rem}
.trk-pb:hover{border-color:var(--ng);color:var(--ng);background:rgba(0,255,136,.1)}
/* WAVEFORM */
.wfc{width:100%;height:80px;background:rgba(0,0,0,.3);border-radius:10px;border:1px solid var(--gb);overflow:hidden}
.wfc canvas{width:100%;height:100%}
/* METERS */
.mtc{display:flex;align-items:flex-end;justify-content:center;gap:4px;height:120px;padding:10px 0}
.mtb{width:8px;height:100%;background:var(--bg3);border-radius:4px;position:relative;overflow:hidden}
.mtf{position:absolute;bottom:0;width:100%;border-radius:4px;background:linear-gradient(to top,var(--ng),var(--ng-br),var(--wrn),var(--dng));transition:height .1s;box-shadow:0 0 8px var(--ng-gl)}
''')

w(r'''/* MASTER CHAIN */
.mch{display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;padding:20px 0}
.mcn{width:100px;height:100px;border-radius:16px;border:1px solid var(--gb);background:var(--card);backdrop-filter:blur(10px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;transition:all var(--tf);cursor:pointer}
.mcn:hover{border-color:var(--ng);box-shadow:0 0 20px var(--ng-gl);transform:translateY(-4px)}
.mcn.an{border-color:var(--ng);background:rgba(0,255,136,.08)}
.mci{font-size:1.5rem}
.mcl{font-family:var(--fm);font-size:.6rem;color:var(--t2);text-transform:uppercase;letter-spacing:1px}
.mca{font-size:1.2rem;color:var(--t3)}
/* GEMA BANNER */
.gem-b{background:linear-gradient(135deg,rgba(0,255,136,.08),rgba(0,255,136,.02),rgba(0,255,136,.05));border:1px solid var(--ng);border-radius:20px;padding:40px;text-align:center;position:relative;overflow:hidden;margin-bottom:24px}
.gem-b::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:conic-gradient(from 0deg,transparent,var(--ng-gl),transparent,transparent);animation:gemr 8s linear infinite;opacity:.3}
@keyframes gemr{to{transform:rotate(360deg)}}
.gem-t{font-family:var(--fd);font-size:2.5rem;font-weight:900;color:var(--ng);text-shadow:0 0 30px var(--ng-gl),0 0 60px var(--ng-gl);letter-spacing:6px;position:relative;z-index:1}
.gem-s{font-family:var(--fm);font-size:.85rem;color:var(--t2);margin-top:8px;letter-spacing:4px;position:relative;z-index:1}
''')

w(r'''/* TIMELINE */
.tl{position:relative;padding-left:30px}
.tl::before{content:'';position:absolute;left:8px;top:0;bottom:0;width:1px;background:linear-gradient(to bottom,var(--ng),var(--gb),transparent)}
.tli{position:relative;margin-bottom:24px;padding-left:20px}
.tli::before{content:'';position:absolute;left:-26px;top:6px;width:10px;height:10px;border-radius:50%;background:var(--ng);border:2px solid var(--bg1);box-shadow:0 0 10px var(--ng-gl)}
.tly{font-family:var(--fd);font-size:.75rem;color:var(--ng);letter-spacing:2px;margin-bottom:4px}
.tlt{font-family:var(--fb);font-size:.9rem;color:var(--t2);line-height:1.5}
/* SOCIAL */
.sg{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px}
.soc{display:flex;align-items:center;gap:14px;padding:18px;border:1px solid var(--gb);border-radius:12px;background:var(--card);cursor:pointer;transition:all var(--tf);text-decoration:none;color:inherit}
.soc:hover{border-color:var(--gbh);background:rgba(0,255,136,.04);transform:translateY(-2px)}
.soc-i{width:40px;height:40px;border-radius:10px;background:var(--gls);border:1px solid var(--gb);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
.soc-l{font-family:var(--fb);font-weight:600;font-size:.9rem}
.soc-h{font-family:var(--fm);font-size:.7rem;color:var(--t3)}
/* DIVIDER */
.dv{height:1px;background:linear-gradient(90deg,transparent,var(--gb),transparent);margin:30px 0}
''')

w(r'''/* TOAST */
.tst-c{position:fixed;bottom:24px;right:24px;z-index:8000;display:flex;flex-direction:column-reverse;gap:8px}
.tst{font-family:var(--fm);font-size:.75rem;padding:12px 20px;border-radius:10px;border:1px solid var(--gb);background:rgba(10,20,15,.95);backdrop-filter:blur(20px);color:var(--t1);box-shadow:0 8px 32px rgba(0,0,0,.4);animation:tin .4s ease forwards;display:flex;align-items:center;gap:10px}
.tst.out{animation:tout .3s ease forwards}
@keyframes tin{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}
@keyframes tout{from{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(30px)}}
/* SECRET PANEL */
#sp{position:fixed;top:0;right:-420px;width:400px;height:100vh;background:rgba(0,10,5,.95);backdrop-filter:blur(30px);border-left:1px solid var(--ng);z-index:5000;padding:30px;transition:right var(--tm);overflow-y:auto;box-shadow:-10px 0 40px rgba(0,255,136,.1)}
#sp.open{right:0}
.sp-t{font-family:var(--fd);font-size:1rem;color:var(--ng);letter-spacing:3px;margin-bottom:20px;text-shadow:0 0 15px var(--ng-gl)}
.sp-m{font-family:var(--fm);font-size:.8rem;color:var(--t2);line-height:1.8}
.sp-x{position:absolute;top:20px;right:20px;width:32px;height:32px;border-radius:8px;border:1px solid var(--gb);background:transparent;color:var(--t2);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all var(--tf)}
.sp-x:hover{border-color:var(--dng);color:var(--dng)}
/* MATRIX */
#mx{position:fixed;inset:0;z-index:9999;pointer-events:none;opacity:0;transition:opacity 1s}
#mx.act{opacity:.12}
/* ANIM */
.fi{opacity:0;transform:translateY(20px);animation:fiu .6s ease forwards}
.fi:nth-child(1){animation-delay:.1s}.fi:nth-child(2){animation-delay:.2s}.fi:nth-child(3){animation-delay:.3s}.fi:nth-child(4){animation-delay:.4s}
@keyframes fiu{to{opacity:1;transform:translateY(0)}}
.kh{position:fixed;bottom:8px;left:8px;font-family:var(--fm);font-size:.55rem;color:var(--t3);opacity:.3;letter-spacing:1px;z-index:50;user-select:none}
/* FOOTER */
.ftb{height:32px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:var(--gls);backdrop-filter:blur(10px);border-top:1px solid var(--gb);font-family:var(--fm);font-size:.6rem;color:var(--t3);flex-shrink:0;letter-spacing:1px}
''')

w(r'''/* RESPONSIVE */
@media(max-width:1024px){.g3{grid-template-columns:repeat(2,1fr)}.g4{grid-template-columns:repeat(2,1fr)}.trk{grid-template-columns:30px 1fr 100px 50px}.trk-bp{display:none}}
@media(max-width:768px){
.sb{width:100%;height:60px;flex-direction:row;bottom:0;top:auto;border-right:none;border-top:1px solid var(--gb);padding:0 8px;z-index:1000}
.sb:hover{width:100%}.sb-lo{display:none}
.sb-nv{flex-direction:row;gap:2px;padding:0;overflow-x:auto;justify-content:space-around}
.ni{padding:8px;flex-direction:column;gap:4px}.ni-lb{opacity:1;font-size:.6rem}.ni.ac::before{display:none}
.sb-bt{display:none}.mc{padding-bottom:60px}
.g2,.g3,.g4{grid-template-columns:1fr}
.gem-t{font-size:1.5rem}.trk{grid-template-columns:30px 1fr 50px}.trk-g{display:none}
.mch{gap:8px}.mcn{width:70px;height:70px}
#sp{width:100%;right:-100%}
}
''')

w('</style></head><body>')

# ========== HTML BODY ==========
w('''<!-- LOADING -->
<div id="ld">
<div class="ld-lo">DUCK</div>
<div class="ld-sb">STUDIO TOOLKIT</div>
<div class="ld-bc"><div class="ld-br" id="ld-br"></div></div>
<div class="ld-tx" id="ld-tx">INICIALIZANDO MÓDULOS...</div>
<div class="ld-vr">v3.0.0 // A GEMA #1 // BELENTANI</div>
</div>

<!-- MATRIX (EASTER EGG) -->
<canvas id="mx"></canvas>

<!-- SECRET PANEL (EASTER EGG) -->
<div id="sp">
<button class="sp-x" onclick="togSP()">X</button>
<div class="sp-t">ACESSO SECRETO</div>
<div class="sp-m">
<p>Você encontrou o painel secreto!</p><br>
<p>A GEMA #1 não é apenas um nome — é um código.</p>
<p>Masterização de Belentani para Duck significa que cada frequência foi esculpida com precisão cirúrgica.</p><br>
<p>Cada batida que você ouve passou por processamento de nível mundial antes de chegar aos seus ouvidos.</p><br>
<p>O segredo está nos detalhes que a maioria não percebe.</p><br>
<p style="color:var(--ng)">"A masterização perfeita não se nota. Se notar, falhou."</p><br>
<p style="color:var(--t3)">— Belentani</p><br><br>
<p>Códigos secretos encontrados: <span id="eec">0</span>/5</p>
</div>
</div>

<!-- TOAST -->
<div class="tst-c" id="tc"></div>
''')

w('''<!-- APP -->
<div id="app">
<!-- SIDEBAR -->
<nav class="sb">
<div class="sb-lo" id="sb-lo" title="Duck Studio Toolkit">D</div>
<div class="sb-nv">
<div class="ni ac" data-pg="dashboard" onclick="nav('dashboard')"><div class="ni-ic">⌂</div><span class="ni-lb">Painel</span></div>
<div class="ni" data-pg="tuner" onclick="nav('tuner')"><div class="ni-ic">♪</div><span class="ni-lb">Afinador</span></div>
<div class="ni" data-pg="logo" onclick="nav('logo')"><div class="ni-ic">◆</div><span class="ni-lb">Logo</span></div>
<div class="ni" data-pg="plugins" onclick="nav('plugins')"><div class="ni-ic">⚙</div><span class="ni-lb">Plugins</span></div>
<div class="ni" data-pg="player" onclick="nav('player')"><div class="ni-ic">▶</div><span class="ni-lb">Player</span></div>
<div class="ni" data-pg="portfolio" onclick="nav('portfolio')"><div class="ni-ic">☰</div><span class="ni-lb">Portfólio</span></div>
<div class="ni" data-pg="mastering" onclick="nav('mastering')"><div class="ni-ic">⚡</div><span class="ni-lb">Masterização</span></div>
<div class="ni" data-pg="contact" onclick="nav('contact')"><div class="ni-ic">✉</div><span class="ni-lb">Contato</span></div>
</div>
<div class="sb-bt">
<div class="ni" onclick="showToast('ℹ','Duck Studio Toolkit v3.0.0 — A Gema #1')"><div class="ni-ic">ℹ</div><span class="ni-lb">Sobre</span></div>
</div>
</nav>
''')

w('''<!-- MAIN -->
<div class="mc">
<header class="tb">
<div class="tb-t" id="tb-t">PAINEL DE CONTROLE</div>
<div class="tb-r">
<div class="tb-ck" id="tb-ck">00:00:00</div>
<div class="tb-st"><div class="sdot"></div><span>ONLINE</span></div>
</div>
</header>
<div class="ca">
''')

# ===== PAGES =====

# DASHBOARD
w('''<!-- PAGE: DASHBOARD -->
<div class="pg ac" id="pg-dashboard">
<div class="gem-b fi"><div class="gem-t">A GEMA #1</div><div class="gem-s">MASTERIZAÇÃO DE BELENTANI PARA DUCK</div></div>
<div class="g4 fi">
<div class="sc"><div class="sv" data-cnt="2847563">0</div><div class="sl">Streams Totais</div></div>
<div class="sc"><div class="sv" data-cnt="147">0</div><div class="sl">Releases</div></div>
<div class="sc"><div class="sv" data-cnt="52800">0</div><div class="sl">Seguidores</div></div>
<div class="sc"><div class="sv" data-cnt="98">0</div><div class="sl">Qualidade %</div></div>
</div>
<div class="dv"></div>
<div class="g2 fi">
<div class="gc"><div class="ch"><span class="ct">Forma de Onda ao Vivo</span></div><div class="wfc"><canvas id="wfc"></canvas></div></div>
<div class="gc"><div class="ch"><span class="ct">Medidores de Nível</span></div><div class="mtc" id="mtc"></div><div style="text-align:center;margin-top:8px"><span style="font-family:var(--fm);font-size:.7rem;color:var(--t3)">L   R   L   R   L   R   L   R</span></div></div>
</div>
<div class="dv"></div>
<div class="gc fi">
<div class="ch"><span class="ct">Trabalhos Recentes</span><button class="btn btn-s" onclick="nav('portfolio')">Ver Tudo</button></div>
<div class="trk" onclick="showToast('▶','Reproduzindo: Noite Eterna')"><div class="trk-n">01</div><div class="trk-i"><h4>Noite Eterna</h4><span>Duck ft. Luna</span></div><div class="trk-g">TRAP</div><div class="trk-bp">140 BPM</div><div><button class="trk-pb">▶</button></div></div>
<div class="trk" onclick="showToast('▶','Reproduzindo: Fogo Interior')"><div class="trk-n">02</div><div class="trk-i"><h4>Fogo Interior</h4><span>Duck</span></div><div class="trk-g">HIPHOP</div><div class="trk-bp">90 BPM</div><div><button class="trk-pb">▶</button></div></div>
<div class="trk