import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search")?.toLowerCase();

  let plugins = await db.plugin.findMany();

  if (search) {
    plugins = plugins.filter(
      (p) =>
        p.name.toLowerCase().includes(search) ||
        p.type.toLowerCase().includes(search)
    );
  }

  return NextResponse.json({ plugins, total: plugins.length });
}
