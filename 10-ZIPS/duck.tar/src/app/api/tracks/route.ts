import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const genre = searchParams.get("genre");
  
  const tracks = await db.track.findMany(
    genre && genre !== "ALL"
      ? { where: { genre } }
      : undefined
  );
  
  const genres = await db.track.groupBy({
    by: ["genre"],
    _count: { genre: true },
  });
  
  const stats = {
    total: tracks.length,
    avgBpm: Math.round(tracks.reduce((s, t) => s + t.bpm, 0) / (tracks.length || 1)),
    topGenre: genres.sort((a, b) => b._count.genre - a._count.genre)[0]?.genre || "—",
    genres: genres.map((g) => ({ name: g.genre, count: g._count.genre })),
  };
  
  return NextResponse.json({ tracks, stats });
}
