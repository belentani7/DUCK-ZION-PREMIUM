import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET() {
  const stats = await db.stat.findMany();
  const map: Record<string, number> = {};
  stats.forEach((s) => { map[s.key] = s.value; });

  return NextResponse.json({
    streams: map["streams"] || 0,
    releases: map["releases"] || 0,
    followers: map["followers"] || 0,
    quality: map["quality"] || 0,
  });
}
