import DuckToolkit from '@/components/duck/DuckToolkit'

export default function Page() {
  return <DuckToolkit />
}
