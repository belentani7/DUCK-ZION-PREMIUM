'use client'

import { useEffect, useState, useCallback } from 'react'

interface LoadingScreenProps {
  onComplete?: () => void
}

const LOADING_MESSAGES = [
  'CARREGANDO MÓDULOS DE ÁUDIO...',
  'INICIALIZANDO AFINADOR...',
  'PREPARANDO PLUGINS...',
  'CARREGANDO PORTFÓLIO...',
  'MASTERIZANDO INTERFACE...',
  'CALIBRANDO NEON VERDE...',
  'A GEMA #1 PRONTA',
]

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [message, setMessage] = useState(LOADING_MESSAGES[0])
  const [visible, setVisible] = useState(true)

  const tick = useCallback(() => {
    setProgress((prev) => {
      const step = Math.floor(prev / (100 / LOADING_MESSAGES.length))
      const next = prev + Math.ceil(100 / LOADING_MESSAGES.length)
      if (step < LOADING_MESSAGES.length) setMessage(LOADING_MESSAGES[step])
      if (next >= 100) {
        setMessage(LOADING_MESSAGES[LOADING_MESSAGES.length - 1])
        setTimeout(() => { setVisible(false); onComplete?.() }, 400)
        return 100
      }
      return next
    })
  }, [onComplete])

  useEffect(() => {
    const interval = setInterval(tick, 350)
    return () => clearInterval(interval)
  }, [tick])

  if (!visible) return null

  return (
    <div className={`fixed inset-0 bg-[#0a0f0d] z-[10000] flex flex-col items-center justify-center transition-all duration-[800ms] ${!visible ? 'opacity-0 invisible pointer-events-none' : ''}`}>
      <div className="font-display text-5xl font-black text-[#00ff88] neon-glow-strong tracking-[8px] mb-2" style={{ animation: 'ldp 1.5s ease-in-out infinite' }}>DUCK</div>
      <div className="font-mono text-sm text-[#8fb8a0] tracking-[4px] mb-10">STUDIO TOOLKIT</div>
      <div className="w-[300px] h-[3px] bg-[#111d19] rounded-[2px] overflow-hidden">
        <div className="h-full rounded-[2px] bg-gradient-to-r from-[#004d29] via-[#00ff88] to-[#39ff14] shadow-[0_0_10px_rgba(0,255,136,0.4)] transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>
      <div className="font-mono text-xs text-[#4a7a62] mt-4 tracking-[2px]">{message}</div>
      <div className="absolute bottom-8 font-mono text-[10px] text-[#4a7a62] tracking-[3px]">v3.0.0 // A GEMA #1 // BELENTANI</div>
    </div>
  )
}
