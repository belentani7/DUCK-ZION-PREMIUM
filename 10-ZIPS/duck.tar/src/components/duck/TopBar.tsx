'use client'

import { useEffect, useState } from 'react'
import { useAppStore } from '@/stores/useAppStore'

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'PAINEL DE CONTROLE',
  tuner: 'AFINADOR CROMÁTICO',
  logo: 'GERADOR DE LOGOS',
  plugins: 'ARSENAL DE PLUGINS',
  player: 'PLAYER DE BEATS',
  portfolio: 'PORTFÓLIO',
  mastering: 'MASTERIZAÇÃO BELENTANI',
  contact: 'CONTATO',
}

export default function TopBar() {
  const currentPage = useAppStore((s) => s.currentPage)
  const [clock, setClock] = useState('00:00:00')

  useEffect(() => {
    const update = () => {
      setClock(
        new Date().toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      )
    }
    update()
    const interval = setInterval(update, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <header className="h-14 flex items-center justify-between px-6 glass-strong border-b border-[rgba(0,255,136,0.15)] shrink-0">
      {/* Page title */}
      <h1 className="font-display text-sm font-semibold tracking-[3px] text-[#00ff88] uppercase neon-glow">
        {PAGE_TITLES[currentPage] || currentPage.toUpperCase()}
      </h1>

      {/* Right side */}
      <div className="flex items-center gap-4">
        {/* Clock */}
        <span className="font-mono text-xs text-[#8fb8a0]">
          {clock}
        </span>

        {/* Online status */}
        <div className="flex items-center gap-1.5 font-mono text-[10px] text-[#00ff88]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] shadow-[0_0_8px_rgba(0,255,136,0.4)] animate-[pulse-neon_2s_ease-in-out_infinite]" />
          <span>ONLINE</span>
        </div>
      </div>
    </header>
  )
}
