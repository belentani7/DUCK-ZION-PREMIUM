import { useAppStore } from '@/stores/useAppStore'

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'PAINEL DE CONTROLE',
  tuner: 'AFINADOR CROMÁTICO',
  logo: 'GERADOR DE LOGOS',
  plugins: 'ARSENAL DE PLUGINS',
  player: 'PLAYER DE BEATS',
  portfolio: 'PORTFÓLIO',
  mastering: 'MASTERIZAÇÃO BELENTANI',
  contact: 'CONTATO',
}

export default function useTitle() {
  const page = useAppStore((s) => s.currentPage)
  return PAGE_TITLES[page] || page.toUpperCase()
}