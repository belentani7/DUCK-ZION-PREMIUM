'use client'

interface FooterBarProps {
  onClick?: () => void
}

export default function FooterBar({ onClick }: FooterBarProps) {
  return (
    <footer onClick={onClick} className="h-8 flex items-center justify-between px-5 glass border-t border-[rgba(0,255,136,0.15)] shrink-0 font-mono text-[10px] text-[#4a7a62] tracking-[1px] cursor-default select-none">
      <span>DUCK STUDIO TOOLKIT v3.0.0</span>
      <span>A GEMA #1 // BELENTANI // 2026</span>
    </footer>
  )
}
