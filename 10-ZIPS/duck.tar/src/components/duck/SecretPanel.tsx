'use client'

import { useAppStore } from '@/stores/useAppStore'
import { X } from 'lucide-react'

export default function SecretPanel() {
  const open = useAppStore((s) => s.secretPanelOpen)
  const toggle = useAppStore((s) => s.toggleSecretPanel)
  const easterEggCount = useAppStore((s) => s.easterEggCount)

  return (
    <aside
      className={`fixed top-0 h-screen w-[400px] bg-[rgba(0,10,5,0.95)] backdrop-blur-[30px] border-l border-[#00ff88] z-[5000] p-8 transition-all duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] overflow-y-auto shadow-[-10px_0_40px_rgba(0,255,136,0.1)] max-lg:w-full ${
        open ? 'right-0' : '-right-[420px]'
      }`}
    >
      {/* Close button */}
      <button
        onClick={toggle}
        className="absolute top-5 right-5 w-8 h-8 rounded-lg border border-[rgba(0,255,136,0.15)] bg-transparent text-[#8fb8a0] cursor-pointer flex items-center justify-center transition-all duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)] hover:border-[#ff3366] hover:text-[#ff3366]"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Title */}
      <h2 className="font-display text-base text-[#00ff88] tracking-[3px] mb-5 neon-glow">
        ACESSO SECRETO
      </h2>

      {/* Content */}
      <div className="font-mono text-sm text-[#8fb8a0] leading-[1.8] space-y-3">
        <p>Você encontrou o painel secreto!</p>
        <p>
          A GEMA #1 não é apenas um nome — é um código.
        </p>
        <p>
          Masterização de Belentani para Duck significa que cada frequência foi
          esculpida com precisão cirúrgica.
        </p>
        <p>
          Cada batida que você ouve passou por processamento de nível mundial
          antes de chegar aos seus ouvidos.
        </p>
        <p>O segredo está nos detalhes que a maioria não percebe.</p>
        <p className="text-[#00ff88]">
          &ldquo;A masterização perfeita não se nota. Se notar, falhou.&rdquo;
        </p>
        <p className="text-[#4a7a62]">— Belentani</p>
        <p>
          Códigos secretos encontrados: {Math.min(easterEggCount, 5)}/5
        </p>
      </div>
    </aside>
  )
}
