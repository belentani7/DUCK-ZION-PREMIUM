'use client'

import { useRef, useEffect, useState, type ReactNode } from 'react'

interface ContentAreaProps {
  children: ReactNode
}

export default function ContentArea({ children }: ContentAreaProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  return (
    <div
      ref={scrollRef}
      className="flex-1 overflow-y-auto overflow-x-hidden p-6 relative scrollbar-neon"
    >
      {children}
    </div>
  )
}
