'use client'

import { useEffect, useRef, useCallback } from 'react'

export default function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)
  const activeRef = useRef(false)

  const start = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    activeRef.current = true
    canvas.style.opacity = '0.12'

    const fontSize = 14
    const cols = Math.floor(canvas.width / fontSize)
    const drops: number[] = []
    for (let i = 0; i < cols; i++) {
      drops[i] = Math.random() * -100
    }

    const chars = 'DUCKGEMA01BELENTANI♦♠♣♥∞◆●'

    const draw = () => {
      if (!activeRef.current || !ctx) return

      ctx.fillStyle = 'rgba(10,15,13,0.05)'
      ctx.fillRect(0, 0, canvas!.width, canvas!.height)

      ctx.fillStyle = '#00ff88'
      ctx.font = `${fontSize}px "Share Tech Mono", monospace`

      for (let i = 0; i < drops.length; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)]
        ctx.fillText(char, i * fontSize, drops[i] * fontSize)

        if (drops[i] * fontSize > canvas!.height && Math.random() > 0.975) {
          drops[i] = 0
        }
        drops[i]++
      }

      animRef.current = requestAnimationFrame(draw)
    }

    draw()

    // Auto-stop after 8 seconds
    setTimeout(() => {
      activeRef.current = false
      if (canvas) canvas.style.opacity = '0'
      cancelAnimationFrame(animRef.current)
    }, 8000)
  }, [])

  const stop = useCallback(() => {
    activeRef.current = false
    cancelAnimationFrame(animRef.current)
  }, [])

  // Expose start/stop via ref or global for Konami code trigger
  useEffect(() => {
    // Attach to window for Konami code easter egg integration
    ;(window as unknown as Record<string, unknown>).__matrixStart = start
    ;(window as unknown as Record<string, unknown>).__matrixStop = stop

    return () => {
      stop()
      delete (window as unknown as Record<string, unknown>).__matrixStart
      delete (window as unknown as Record<string, unknown>).__matrixStop
    }
  }, [start, stop])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-[9999] pointer-events-none opacity-0 transition-opacity duration-1000"
    />
  )
}
