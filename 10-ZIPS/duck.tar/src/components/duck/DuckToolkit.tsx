'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { useAppStore, type PageId } from '@/stores/useAppStore'
import Sidebar from './Sidebar'
import TopBar from './TopBar'
import ContentArea from './ContentArea'
import LoadingScreen from './LoadingScreen'
import SecretPanel from './SecretPanel'
import MatrixRain from './MatrixRain'
import FooterBar from './FooterBar'
import DashboardPage from './sections/DashboardPage'
import TunerPage from './sections/TunerPage'
import LogoPage from './sections/LogoPage'
import PluginsPage from './sections/PluginsPage'
import PlayerPage from './sections/PlayerPage'
import PortfolioPage from './sections/PortfolioPage'
import MasteringPage from './sections/MasteringPage'
import ContactPage from './sections/ContactPage'

const PAGES: Record<PageId, React.ComponentType> = {
  dashboard: DashboardPage,
  tuner: TunerPage,
  logo: LogoPage,
  plugins: PluginsPage,
  player: PlayerPage,
  portfolio: PortfolioPage,
  mastering: MasteringPage,
  contact: ContactPage,
}

export default function DuckToolkit() {
  const [loaded, setLoaded] = useState(false)
  const currentPage = useAppStore((s) => s.currentPage)
  const incrementEasterEgg = useAppStore((s) => s.incrementEasterEgg)
  const easterEggCount = useAppStore((s) => s.easterEggCount)
  const toggleSecretPanel = useAppStore((s) => s.toggleSecretPanel)
  const konamiRef = useRef<number[]>([])
  const gemaBufRef = useRef('')
  const tripleClickRef = useRef<{ clicks: number; timer: ReturnType<typeof setTimeout> | null }>({ clicks: 0, timer: null })

  // Loading
  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 2800)
    return () => clearTimeout(timer)
  }, [])

  // Easter Egg 1: Konami Code
  useEffect(() => {
    const KONAMI = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65]
    const handler = (e: KeyboardEvent) => {
      konamiRef.current.push(e.keyCode)
      if (konamiRef.current.length > 10) konamiRef.current.shift()
      if (konamiRef.current.join(',') === KONAMI.join(',')) {
        if (easterEggCount < 5) incrementEasterEgg()
        // @ts-expect-error matrix function
        if (window.__matrixStart) window.__matrixStart()
        konamiRef.current = []
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [easterEggCount, incrementEasterEgg])

  // Easter Egg 3: Type 'gema'
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      gemaBufRef.current += e.key
      if (gemaBufRef.current.length > 10) gemaBufRef.current = gemaBufRef.current.slice(-10)
      if (gemaBufRef.current.includes('gema')) {
        if (easterEggCount < 5) incrementEasterEgg()
        toggleSecretPanel()
        gemaBufRef.current = ''
      }
    }
    window.addEventListener('keypress', handler)
    return () => window.removeEventListener('keypress', handler)
  }, [easterEggCount, incrementEasterEgg, toggleSecretPanel])

  // Easter Egg 4: Triple click on stat values
  useEffect(() => {
    const handler = () => {
      const t = tripleClickRef.current
      t.clicks++
      if (t.timer) clearTimeout(t.timer)
      t.timer = setTimeout(() => { t.clicks = 0 }, 500)
      if (t.clicks === 3 && easterEggCount < 5) {
        incrementEasterEgg()
        document.querySelectorAll('[data-count]').forEach(el => { el.textContent = '∞' })
      }
    }
    document.querySelectorAll('[data-count]').forEach(el => el.addEventListener('click', handler))
    return () => { document.querySelectorAll('[data-count]').forEach(el => el.removeEventListener('click', handler)) }
  }, [easterEggCount, incrementEasterEgg])

  // Easter Egg 5: Click version text
  const handleVersionClick = useCallback(() => {
    if (easterEggCount < 5) incrementEasterEgg()
  }, [easterEggCount, incrementEasterEgg])

  const PageComponent = PAGES[currentPage]

  return (
    <>
      <LoadingScreen onComplete={() => setLoaded(true)} />
      <MatrixRain />
      <SecretPanel />
      <div className={`flex h-screen w-screen relative z-[1] transition-opacity duration-600 ${loaded ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <TopBar />
          <ContentArea>
            <PageComponent />
          </ContentArea>
          <FooterBar onClick={handleVersionClick} />
        </div>
      </div>
      {/* Konami hint */}
      <div className="fixed bottom-2 left-2 font-mono text-[9px] text-[#4a7a62] opacity-30 tracking-[1px] z-50 select-none">
        v3.0.0 // A GEMA #1 // BELENTANI
      </div>
    </>
  )
}
