'use client'

import { useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/stores/useAppStore'

export default function PlayerPage() {
  const { tracks, setTracks, playerTrack, playerPlaying, playerProgress, setPlayerTrack, togglePlay, nextTrack, prevTrack } = useAppStore()
  const cvRef = useRef<HTMLCanvasElement>(null)
  const [progress, setProgress] = useState(0)

  useEffect(() => { fetch('/api/tracks').then(r => r.json()).then(d => setTracks(d.tracks)) }, [setTracks])

  useEffect(() => {
    const c = cvRef.current
    if (!c) return
    const x = c.getContext('2d')
    if (!x) return
    const resize = () => { c.width = c.parentElement?.offsetWidth || 500; c.height = c.parentElement?.offsetHeight || 80 }
    resize()
    window.addEventListener('resize', resize)
    let raf: number
    const draw = () => {
      if (!c.width) return
      x.clearRect(0, 0, c.width, c.height)
      const pw = c.width * (progress / 100)
      x.fillStyle = 'rgba(0,255,136,0.15)'
      x.fillRect(0, 0, pw, c.height)
      x.fillStyle = 'rgba(0,255,136,0.8)'
      x.fillRect(pw - 2, 0, 2, c.height)
      if (playerPlaying) setProgress(p => (p + 0.1) % 100)
      raf = requestAnimationFrame(draw)
    }
    draw()
    return () => { window.removeEventListener('resize', resize); cancelAnimationFrame(raf) }
  }, [progress, playerPlaying])

  const t = tracks[playerTrack]

  return (
    <>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-6">Player de Beats</h3>
        <div className="text-center py-5">
          <div className="w-[140px] h-[140px] rounded-full border-2 border-[rgba(0,255,136,0.15)] mx-auto mb-5 flex items-center justify-center bg-[rgba(13,25,20,0.6)] font-display text-4xl text-[#00ff88] neon-glow gema-rotate">D</div>
          <div className="font-sans text-xl font-bold mb-1">{t?.title || 'Selecione uma Faixa'}</div>
          <div className="font-mono text-sm text-[#8fb8a0] mb-5">{t ? `${t.artist} — ${t.genre} — ${t.bpm} BPM` : '—'}</div>
          <div className="max-w-[500px] mx-auto mb-4 cursor-pointer rounded-[10px] border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] overflow-hidden h-20"><canvas ref={cvRef} /></div>
          <div className="flex items-center justify-center gap-4">
            <button onClick={() => prevTrack(tracks.length)} className="font-sans font-semibold text-xs px-3 py-1.5 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,255,136,0.03)] text-[#e0f5ea] cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88]">◀◀</button>
            <button onClick={togglePlay} className="w-[50px] h-[50px] rounded-full border border-[#00ff88] bg-gradient-to-br from-[#004d29] to-[rgba(0,255,136,0.2)] text-[#00ff88] flex items-center justify-center cursor-pointer transition-all hover:shadow-[0_0_30px_rgba(0,255,136,0.25)] text-xl">{playerPlaying ? '❚❚' : '▶'}</button>
            <button onClick={() => nextTrack(tracks.length)} className="font-sans font-semibold text-xs px-3 py-1.5 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,255,136,0.03)] text-[#e0f5ea] cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88]">▶▶</button>
          </div>
        </div>
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Fila de Reprodução</h3>
        <div className="max-h-[400px] overflow-y-auto scrollbar-neon">
          {tracks.map((tr, i) => (
            <div key={tr.id} onClick={() => setPlayerTrack(i)} className={`grid grid-cols-[30px_1fr_100px_50px] items-center gap-3.5 py-2.5 px-3.5 border rounded-[10px] bg-[rgba(13,25,20,0.6)] mb-1.5 cursor-pointer transition-all ${i === playerTrack ? 'border-[#00ff88] bg-[rgba(0,255,136,0.08)]' : 'border-[rgba(0,255,136,0.15)] hover:border-[rgba(0,255,136,0.4)]'} `}>
              <span className="font-mono text-xs text-[#4a7a62] text-center">{String(i + 1).padStart(2, '0')}</span>
              <div><h4 className="font-sans font-semibold text-sm text-[#e0f5ea]">{tr.title}</h4><span className="font-mono text-[11px] text-[#4a7a62]">{tr.artist}</span></div>
              <span className="font-mono text-[11px] text-[#8fb8a0] text-center">{tr.bpm} BPM</span>
              <button className="w-7 h-7 rounded-full border border-[rgba(0,255,136,0.15)] bg-transparent text-[#8fb8a0] flex items-center justify-center cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88] text-[10px]">{i === playerTrack && playerPlaying ? '❚❚' : '▶'}</button>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}