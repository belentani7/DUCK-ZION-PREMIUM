'use client'

const SOCIALS = [
  { icon: '📷', name: 'Instagram', handle: '@duck.prod' },
  { icon: '💬', name: 'WhatsApp', handle: '+55 (XX) XXXXX-XXXX' },
  { icon: '🎵', name: 'Spotify', handle: 'Duck Producer' },
  { icon: '📧', name: 'Email', handle: 'duck@studio.com' },
  { icon: '🎬', name: 'YouTube', handle: 'Duck Beats' },
  { icon: '☁', name: 'SoundCloud', handle: '@duckbeats' },
]

export default function ContactPage() {
  return (
    <>
      <div className="relative rounded-[20px] p-8 text-center overflow-hidden mb-6 border border-[#00ff88] bg-gradient-to-br from-[rgba(0,255,136,0.08)] to-[rgba(0,255,136,0.02)]">
        <div className="absolute inset-0 gema-rotate opacity-30" style={{ background: 'conic-gradient(from 0deg, transparent, rgba(0,255,136,0.4), transparent, transparent)' }} />
        <h2 className="font-display text-2xl md:text-4xl font-black text-[#00ff88] neon-glow-strong tracking-[6px] relative z-10">CONTATO</h2>
        <p className="font-mono text-sm text-[#8fb8a0] mt-2 tracking-[4px] relative z-10">VAMOS CRIAR ALGO JUNTOS</p>
      </div>

      <div className="glass rounded-2xl p-6 mb-5">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Redes Sociais</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SOCIALS.map(s => (
            <a key={s.name} href="#" className="flex items-center gap-3.5 p-4 border border-[rgba(0,255,136,0.15)] rounded-xl bg-[rgba(13,25,20,0.6)] cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)] hover:bg-[rgba(0,255,136,0.04)] hover:-translate-y-0.5">
              <div className="w-10 h-10 rounded-[10px] bg-[rgba(0,255,136,0.03)] border border-[rgba(0,255,136,0.15)] flex items-center justify-center text-xl shrink-0">{s.icon}</div>
              <div><div className="font-sans font-semibold text-sm text-[#e0f5ea]">{s.name}</div><div className="font-mono text-[11px] text-[#4a7a62]">{s.handle}</div></div>
            </a>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Localização</h3>
        <div className="flex items-center gap-3">
          <span className="text-2xl">📍</span>
          <div><div className="font-sans text-base font-semibold">Brasil</div><div className="font-mono text-sm text-[#8fb8a0]">Disponível para projetos remotos e presenciais</div></div>
        </div>
      </div>
    </>
  )
}