'use client'

import { useEffect, useState } from 'react'
import { useAppStore } from '@/stores/useAppStore'

export default function PortfolioPage() {
  const [tracks, setTracks] = useState<Array<{ id: string; title: string; artist: string; genre: string; bpm: number; streams: number }>>([])
  const [genres, setGenres] = useState<Array<{ name: string; count: number }>>([])
  const [avgBpm, setAvgBpm] = useState(0)
  const [topGenre, setTopGenre] = useState('—')
  const [filter, setFilter] = useState('TODOS')
  const setPlayerTrack = useAppStore(s => s.setPlayerTrack)
  const setCurrentPage = useAppStore(s => s.setCurrentPage)

  useEffect(() => {
    fetch('/api/tracks').then(r => r.json()).then(d => {
      setTracks(d.tracks)
      setGenres(d.stats.genres)
      setAvgBpm(d.stats.avgBpm)
      setTopGenre(d.stats.topGenre)
    })
  }, [])

  const filtered = filter === 'TODOS' ? tracks : tracks.filter(t => t.genre === filter)

  return (
    <>
      <div className="relative rounded-[20px] p-8 text-center overflow-hidden mb-6 border border-[#00ff88] bg-gradient-to-br from-[rgba(0,255,136,0.08)] to-[rgba(0,255,136,0.02)]">
        <div className="absolute inset-0 gema-rotate opacity-30" style={{ background: 'conic-gradient(from 0deg, transparent, rgba(0,255,136,0.4), transparent, transparent)' }} />
        <h2 className="font-display text-2xl md:text-4xl font-black text-[#00ff88] neon-glow-strong tracking-[6px] relative z-10">PORTFÓLIO</h2>
        <p className="font-mono text-sm text-[#8fb8a0] mt-2 tracking-[4px] relative z-10">PRODUÇÕES MASTERIZADAS POR BELENTANI</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Por Gênero</h3>
          <div className="grid grid-cols-2 gap-3">
            {[...genres].sort((a, b) => b.count - a.count).map(g => (
              <div key={g.name} onClick={() => setFilter(g.name)} className={`glass rounded-xl p-4 text-center cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)] ${filter === g.name ? 'border-[#00ff88]' : 'border-[rgba(0,255,136,0.15)]'}`}>
                <div className="font-display text-sm font-bold text-[#00ff88]">{g.name}</div>
                <div className="font-mono text-[11px] text-[#8fb8a0] mt-1">{g.count} faixas</div>
              </div>
            ))}
            <div onClick={() => setFilter('TODOS')} className={`glass rounded-xl p-4 text-center cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)] ${filter === 'TODOS' ? 'border-[#00ff88]' : 'border-[rgba(0,255,136,0.15)]'}`}>
              <div className="font-display text-sm font-bold text-[#00ff88]">TODOS</div>
              <div className="font-mono text-[11px] text-[#8fb8a0] mt-1">{tracks.length} faixas</div>
            </div>
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Estatísticas</h3>
          <div className="flex flex-col gap-3">
            {[['Total de Faixas', tracks.length], ['BPM Médio', avgBpm + ' BPM'], ['Gênero Principal', topGenre], ['Artistas Colaborados', '12+']].map(([l, v]) => (
              <div key={l as string} className="flex justify-between"><span className="font-mono text-sm text-[#8fb8a0]">{l as string}</span><span className="font-mono text-sm text-[#00ff88]">{v as string | number}</span></div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase">Todas as Produções</h3>
          <span className="font-mono text-xs text-[#4a7a62]">Mostrando: {filter}</span>
        </div>
        <div className="max-h-[500px] overflow-y-auto scrollbar-neon">
          {filtered.map((t, i) => (
            <div key={t.id} onClick={() => { useAppStore.getState().setTracks(tracks); setPlayerTrack(tracks.indexOf(t)); setCurrentPage('player') }} className="grid grid-cols-[40px_1fr_130px_90px_50px] items-center gap-3.5 py-3 px-4 border border-[rgba(0,255,136,0.15)] rounded-[10px] bg-[rgba(13,25,20,0.6)] mb-1.5 cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)] hover:bg-[rgba(0,255,136,0.04)]">
              <span className="font-mono text-xs text-[#4a7a62] text-center">{String(i + 1).padStart(2, '0')}</span>
              <div><h4 className="font-sans font-semibold text-sm text-[#e0f5ea]">{t.title}</h4><span className="font-mono text-[11px] text-[#4a7a62]">{t.artist}</span></div>
              <span className="font-mono text-[11px] py-1 px-2.5 rounded-full border border-[rgba(0,255,136,0.15)] text-[#8fb8a0] text-center">{t.genre}</span>
              <span className="font-mono text-xs text-[#00ff88] text-center">{t.bpm} BPM</span>
              <button className="w-8 h-8 rounded-full border border-[rgba(0,255,136,0.15)] bg-transparent text-[#8fb8a0] flex items-center justify-center cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88] hover:bg-[rgba(0,255,136,0.1)] text-xs">▶</button>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}