'use client'

import { useEffect, useState } from 'react'

interface Plugin { id: string; name: string; type: string; tier: string }

const TIER_MAP: Record<string, { label: string; cls: string }> = {
  essential: { label: 'ESSENCIAL', cls: 'border-[#00ff88] text-[#00ff88] bg-[rgba(0,255,136,0.08)]' },
  pro: { label: 'PRO', cls: 'border-[#00ffd5] text-[#00ffd5] bg-[rgba(0,255,213,0.08)]' },
  vst: { label: 'VST', cls: 'border-[#ffaa00] text-[#ffaa00] bg-[rgba(255,170,0,0.08)]' },
}

export default function PluginsPage() {
  const [plugins, setPlugins] = useState<Plugin[]>([])
  const [search, setSearch] = useState('')
  const [total, setTotal] = useState(0)

  useEffect(() => {
    fetch('/api/plugins').then(r => r.json()).then(d => { setPlugins(d.plugins); setTotal(d.total) })
  }, [])

  const filtered = search
    ? plugins.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.type.toLowerCase().includes(search.toLowerCase()))
    : plugins

  return (
    <>
      <div className="glass rounded-2xl p-6 mb-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase">Arsenal de Plugins</h3>
          <span className="font-mono text-xs text-[#4a7a62]">{total} catalogados</span>
        </div>
        {filtered.map(p => {
          const tier = TIER_MAP[p.tier] || TIER_MAP.essential
          return (
            <div key={p.id} className="flex items-center justify-between py-3.5 px-4.5 border border-[rgba(0,255,136,0.15)] rounded-[10px] bg-[rgba(13,25,20,0.6)] mb-2 transition-all hover:border-[rgba(0,255,136,0.4)] hover:bg-[rgba(0,255,136,0.04)]">
              <div>
                <div className="font-sans font-semibold text-sm text-[#e0f5ea]">{p.name}</div>
                <div className="font-mono text-[11px] text-[#4a7a62] uppercase tracking-[1px]">{p.type}</div>
              </div>
              <span className={`font-mono text-[11px] px-2.5 py-0.5 rounded-full border ${tier.cls}`}>{tier.label}</span>
            </div>
          )
        })}
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Busca</h3>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar plugin..." className="w-full font-mono text-sm py-2.5 px-4 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] text-[#e0f5ea] outline-none focus:border-[#00ff88] placeholder:text-[#4a7a62]" />
      </div>
    </>
  )
}
