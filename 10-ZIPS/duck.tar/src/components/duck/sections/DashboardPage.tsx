'use client'

import { useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/stores/useAppStore'

export default function DashboardPage() {
  const [stats, setStats] = useState({ streams: 0, releases: 0, followers: 0, quality: 0 })
  const [loaded, setLoaded] = useState(false)
  const wfRef = useRef<HTMLCanvasElement>(null)
  const meterBars = useRef<HTMLDivElement[]>([])

  useEffect(() => {
    fetch('/api/stats').then(r => r.json()).then(setStats)
  }, [])

  useEffect(() => {
    if (!loaded) return
    document.querySelectorAll('[data-count]').forEach(el => {
      const target = parseInt(el.getAttribute('data-count') || '0')
      let cur = 0
      const inc = Math.max(1, Math.floor(target / 50))
      const iv = setInterval(() => {
        cur += inc
        if (cur >= target) { cur = target; clearInterval(iv) }
        el.textContent = cur.toLocaleString('pt-BR')
      }, 30)
    })
  }, [loaded])

  useEffect(() => {
    const c = wfRef.current
    if (!c) return
    const x = c.getContext('2d')
    if (!x) return
    const resize = () => { c.width = c.parentElement?.offsetWidth || 400; c.height = c.parentElement?.offsetHeight || 80 }
    resize()
    window.addEventListener('resize', resize)
    let t = 0
    let raf: number
    const draw = () => {
      x.clearRect(0, 0, c.width, c.height)
      x.strokeStyle = 'rgba(0,255,136,0.6)'
      x.lineWidth = 2
      x.shadowColor = 'rgba(0,255,136,0.4)'
      x.shadowBlur = 8
      x.beginPath()
      for (let i = 0; i < c.width; i++) {
        const y = c.height / 2 + Math.sin(i * 0.02 + t) * 20 * Math.sin(i * 0.005 + t * 0.3) + Math.sin(i * 0.01 + t * 1.5) * 10
        i === 0 ? x.moveTo(i, y) : x.lineTo(i, y)
      }
      x.stroke()
      x.shadowBlur = 0
      t += 0.03
      raf = requestAnimationFrame(draw)
    }
    draw()
    return () => { window.removeEventListener('resize', resize); cancelAnimationFrame(raf) }
  }, [])

  useEffect(() => {
    const iv = setInterval(() => {
      meterBars.current.forEach((bar, i) => {
        if (!bar) return
        const h = 20 + Math.random() * 60 + Math.sin(Date.now() * 0.003 + i) * 20
        bar.style.height = `${Math.max(5, Math.min(95, h))}%`
      })
    }, 100)
    return () => clearInterval(iv)
  }, [])

  const recentTracks = [
    { n: 'Noite Eterna', a: 'Duck ft. Luna', g: 'TRAP', b: '140 BPM' },
    { n: 'Fogo Interior', a: 'Duck', g: 'HIPHOP', b: '90 BPM' },
    { n: 'Neon Dreams', a: 'Duck & Zay', g: 'POP', b: '128 BPM' },
  ]

  return (
    <>
      <div className="relative rounded-[20px] p-10 text-center overflow-hidden mb-6 border border-[#00ff88] bg-gradient-to-br from-[rgba(0,255,136,0.08)] via-[rgba(0,255,136,0.02)] to-[rgba(0,255,136,0.05)]">
        <div className="absolute inset-0 gema-rotate opacity-30" style={{ background: 'conic-gradient(from 0deg, transparent, rgba(0,255,136,0.4), transparent, transparent)' }} />
        <h2 className="font-display text-3xl md:text-5xl font-black text-[#00ff88] neon-glow-strong tracking-[6px] relative z-10">A GEMA #1</h2>
        <p className="font-mono text-sm text-[#8fb8a0] mt-2 tracking-[4px] relative z-10">MASTERIZAÇÃO DE BELENTANI PARA DUCK</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { v: stats.streams, l: 'Streams Totais' },
          { v: stats.releases, l: 'Releases' },
          { v: stats.followers, l: 'Seguidores' },
          { v: stats.quality, l: 'Qualidade %' },
        ].map((s, i) => (
          <div key={i} className="glass rounded-[14px] p-5 text-center glass-card-hover cursor-default">
            <div className="font-display text-2xl lg:text-3xl font-extrabold text-[#00ff88] neon-glow" data-count={s.v}>0</div>
            <div className="text-sm text-[#8fb8a0] mt-1 uppercase tracking-[1px]">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Forma de Onda ao Vivo</h3>
          <div className="w-full h-20 rounded-[10px] border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] overflow-hidden">
            <canvas ref={wfRef} />
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Medidores de Nível</h3>
          <div className="flex items-end justify-center gap-1 h-[120px] py-2.5">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="w-2 h-full bg-[#111d19] rounded-[4px] relative overflow-hidden">
                <div
                  ref={el => { if (el) meterBars.current[i] = el }}
                  className="absolute bottom-0 w-full rounded-[4px] bg-gradient-to-t from-[#00ff88] via-[#39ff14] via-[#ffaa00] to-[#ff3366]"
                  style={{ height: '50%', boxShadow: '0 0 8px rgba(0,255,136,0.4)', transition: 'height 0.1s' }}
                />
              </div>
            ))}
          </div>
          <div className="text-center mt-2"><span className="font-mono text-[10px] text-[#4a7a62]">L   R   L   R   L   R   L   R</span></div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase">Trabalhos Recentes</h3>
          <button onClick={() => useAppStore.getState().setCurrentPage('portfolio')} className="font-sans font-semibold text-xs px-3.5 py-1.5 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,255,136,0.03)] text-[#e0f5ea] cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88] hover:shadow-[0_0_20px_rgba(0,255,136,0.15)] uppercase tracking-[1px]">Ver Tudo</button>
        </div>
        {recentTracks.map((t, i) => (
          <div key={i} className="grid grid-cols-[40px_1fr_130px_90px_50px] items-center gap-3.5 py-3 px-4 border border-[rgba(0,255,136,0.15)] rounded-[10px] bg-[rgba(13,25,20,0.6)] mb-1.5 cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)] hover:bg-[rgba(0,255,136,0.04)]">
            <span className="font-mono text-xs text-[#4a7a62] text-center">{String(i + 1).padStart(2, '0')}</span>
            <div><h4 className="font-sans font-semibold text-sm text-[#e0f5ea]">{t.n}</h4><span className="font-mono text-[11px] text-[#4a7a62]">{t.a}</span></div>
            <span className="font-mono text-[11px] py-1 px-2.5 rounded-full border border-[rgba(0,255,136,0.15)] text-[#8fb8a0] text-center">{t.g}</span>
            <span className="font-mono text-xs text-[#00ff88] text-center">{t.b}</span>
            <button className="w-8 h-8 rounded-full border border-[rgba(0,255,136,0.15)] bg-transparent text-[#8fb8a0] flex items-center justify-center cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88] hover:bg-[rgba(0,255,136,0.1)] text-xs">▶</button>
          </div>
        ))}
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Linha do Tempo</h3>
        <div className="relative pl-[30px]">
          <div className="absolute left-2 top-0 bottom-0 w-px bg-gradient-to-b from-[#00ff88] via-[rgba(0,255,136,0.15)] to-transparent" />
          {[
            { y: '2026', t: 'Lançamento do Duck Studio Toolkit v3.0 — A Gema #1. Pack profissional completo com ferramentas de estúdio de nível Hollywood.' },
            { y: '2025', t: 'Parceria com Belentani para masterização exclusiva. Novo padrão de qualidade sonora estabelecido no cenário nacional.' },
            { y: '2024', t: 'Expansão para produção de POP e R&B. Colaborações com artistas internacionais. Marco de 2 milhões de streams totais.' },
            { y: '2023', t: 'Primeiro release viral no Trap. Início da carreira profissional como produtor e beatmaker independente.' },
          ].map((item, i) => (
            <div key={i} className="relative mb-6 pl-5">
              <div className="absolute -left-[26px] top-1.5 w-2.5 h-2.5 rounded-full bg-[#00ff88] border-2 border-[#0a0f0d] shadow-[0_0_10px_rgba(0,255,136,0.4)]" />
              <div className="font-display text-xs text-[#00ff88] tracking-[2px] mb-1">{item.y}</div>
              <p className="font-sans text-sm text-[#8fb8a0] leading-relaxed">{item.t}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
