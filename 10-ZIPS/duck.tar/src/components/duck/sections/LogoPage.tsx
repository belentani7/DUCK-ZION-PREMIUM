'use client'

import { useRef, useState } from 'react'

const STYLES: Record<string, { shadow: string; weight: string; spacing: string; extra?: string }> = {
  neon: { shadow: '0 0 10px var(--c),0 0 20px var(--c),0 0 40px var(--c)', weight: 'font-black', spacing: 'tracking-[4px]' },
  minimal: { shadow: 'none', weight: 'font-normal', spacing: 'tracking-[8px]' },
  bold: { shadow: '0 0 30px var(--c),0 0 60px var(--c)', weight: 'font-black', spacing: 'tracking-[2px]' },
  retro: { shadow: '2px 2px 0 #000,-1px -1px 0 #000', weight: 'font-bold', spacing: 'tracking-[6px]' },
  gema: { shadow: '0 0 10px var(--c),0 0 20px var(--c),0 0 40px var(--c),0 0 80px var(--c),0 0 120px var(--c)', weight: 'font-black', spacing: 'tracking-[10px]', extra: 'border-2 shadow-[0_0_30px_rgba(0,255,136,0.4)]' },
}

const COLORS = ['#00ff88', '#00ffd5', '#ff3366', '#ffaa00', '#b8ff00', '#ffffff']
const SIZES = ['text-3xl', 'text-4xl', 'text-6xl', 'text-7xl', 'text-8xl']

export default function LogoPage() {
  const [text, setText] = useState('DUCK')
  const [style, setStyle] = useState('neon')
  const [color, setColor] = useState('#00ff88')
  const [size, setSize] = useState(2)
  const previewRef = useRef<HTMLDivElement>(null)
  const s = STYLES[style]

  const download = () => {
    const cv = document.createElement('canvas')
    cv.width = 800; cv.height = 800
    const x = cv.getContext('2d')!
    x.fillStyle = '#0a0f0d'; x.fillRect(0, 0, 800, 800)
    x.fillStyle = color
    x.font = `900 120px Orbitron, sans-serif`
    x.textAlign = 'center'; x.textBaseline = 'middle'
    x.shadowColor = color; x.shadowBlur = 40
    x.fillText(text, 400, 400)
    const a = document.createElement('a')
    a.download = 'duck-logo.png'
    a.href = cv.toDataURL()
    a.click()
  }

  return (
    <>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Gerador de Logos</h3>
        <div
          ref={previewRef}
          className="w-[200px] h-[200px] rounded-[20px] border-2 border-[rgba(0,255,136,0.15)] bg-[#0a0f0d] flex items-center justify-center mx-auto mb-6 font-display text-5xl font-black text-[#00ff88] transition-all duration-300 overflow-hidden relative"
          style={{ ['--c' as string]: color, color, textShadow: s.shadow, fontWeight: 'inherit' }}
        >
          <span className={`${SIZES[size]} ${s.weight} ${s.spacing} ${s.extra || ''}`}>{text}</span>
        </div>
        <div className="flex flex-col gap-4 max-w-[400px] mx-auto">
          <div><label className="font-mono text-xs text-[#8fb8a0] block mb-2">NOME DO ARTISTA</label><input value={text} onChange={e => setText(e.target.value)} className="w-full font-mono text-sm py-2.5 px-4 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] text-[#e0f5ea] outline-none focus:border-[#00ff88]" /></div>
          <div><label className="font-mono text-xs text-[#8fb8a0] block mb-2">ESTILO</label>
            <select value={style} onChange={e => setStyle(e.target.value)} className="w-full font-mono text-sm py-2.5 px-4 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] text-[#e0f5ea] outline-none focus:border-[#00ff88]">
              <option value="neon">Neon Glow</option><option value="minimal">Minimalista</option><option value="bold">Pesado / Bold</option><option value="retro">Retrô Futurista</option><option value="gema">A Gema Especial</option>
            </select></div>
          <div><label className="font-mono text-xs text-[#8fb8a0] block mb-2">TAMANHO</label><input type="range" min="0" max="4" value={size} onChange={e => setSize(+e.target.value)} className="w-full" /></div>
          <div><label className="font-mono text-xs text-[#8fb8a0] block mb-2">COR</label>
            <select value={color} onChange={e => setColor(e.target.value)} className="w-full font-mono text-sm py-2.5 px-4 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] text-[#e0f5ea] outline-none focus:border-[#00ff88]">
              {COLORS.map(c => <option key={c} value={c}>{c === '#00ff88' ? 'Neon Verde' : c === '#00ffd5' ? 'Neon Ciano' : c === '#ff3366' ? 'Neon Rosa' : c === '#ffaa00' ? 'Neon Dourado' : c === '#b8ff00' ? 'Neon Lima' : 'Branco Puro'}</option>)}
            </select></div>
          <button onClick={download} className="font-sans font-semibold text-sm px-6 py-2.5 rounded-lg border border-[#00ff88] bg-gradient-to-br from-[#004d29] to-[rgba(0,255,136,0.2)] text-[#00ff88] cursor-pointer transition-all hover:shadow-[0_0_30px_rgba(0,255,136,0.25)] uppercase tracking-[1px] mt-2">BAIXAR LOGO</button>
        </div>
      </div>
    </>
  )
}
