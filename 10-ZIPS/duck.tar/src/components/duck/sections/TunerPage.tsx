'use client'

import { useRef, useState, useEffect, useCallback } from 'react'

const NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

export default function TunerPage() {
  const [note, setNote] = useState('--')
  const [freq, setFreq] = useState('--- Hz')
  const [status, setStatus] = useState('CLIQUE EM INICIAR PARA USAR O MICROFONE')
  const [indicatorPos, setIndicatorPos] = useState(50)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const rafRef = useRef<number>(0)

  const detectPitch = useCallback((buf: Float32Array, sr: number) => {
    let rms = 0
    for (let i = 0; i < buf.length; i++) rms += buf[i] * buf[i]
    rms = Math.sqrt(rms / buf.length)
    if (rms < 0.01) return -1
    const SIZE = buf.length
    const c = new Float32Array(SIZE / 2)
    for (let i = 0; i < SIZE / 2; i++) c[i] = buf[2 * i] || 0
    let maxVal = 0, maxIdx = 0
    for (let k = 2; k < SIZE / 2; k++) {
      let s = 0
      for (let n = 0; n < SIZE / 2; n++) s += c[n] * Math.cos((2 * Math.PI * k * n) / SIZE)
      if (s > maxVal) { maxVal = s; maxIdx = k }
    }
    return maxIdx * sr / SIZE
  }, [])

  const freqToNote = (f: number) => { const n = 12 * Math.log2(f / 440) + 69; return NOTES[Math.round(n) % 12] }

  useEffect(() => {
    if (!active) return
    const analyser = analyserRef.current
    if (!analyser) return

    const loop = () => {
      const buf = new Float32Array(analyser.fftSize)
      analyser.getFloatTimeDomainData(buf)
      const f = detectPitch(buf, 44100)
      if (f > 0) {
        const n = freqToNote(f)
        setNote(n)
        setFreq(Math.round(f) + ' Hz')
        const cents = Math.round(1200 * Math.log2(f / (440 * Math.pow(2, (NOTES.indexOf(n) - 9) / 12))))
        const pos = Math.max(5, Math.min(95, 50 + cents * 2))
        setIndicatorPos(pos)
        setStatus(Math.abs(cents) < 5 ? 'AFINADO' : cents > 0 ? 'AGUDO ' + Math.abs(cents) + '¢' : 'GRAVE ' + Math.abs(cents) + '¢')
      }
      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(rafRef.current)
  }, [active, detectPitch])

  const toggle = async () => {
    if (active) {
      setActive(false)
      setStatus('MICROFONE DESLIGADO')
      setNote('--'); setFreq('--- Hz')
      streamRef.current?.getTracks().forEach(t => t.stop())
      streamRef.current = null
      return
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream
      const ctx = new AudioContext()
      const src = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 2048
      src.connect(analyser)
      analyserRef.current = analyser
      setActive(true)
      setStatus('TOQUE UMA NOTA...')
    } catch {
      setStatus('MICROFONE NÃO DISPONÍVEL')
    }
  }

  const handlePlayRef = (f: number) => {
    const ctx = new AudioContext()
    const osc = ctx.createOscillator()
    const g = ctx.createGain()
    osc.frequency.value = f
    osc.type = 'sine'
    g.gain.setValueAtTime(0.3, ctx.currentTime)
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5)
    osc.connect(g)
    g.connect(ctx.destination)
    osc.start()
    osc.stop(ctx.currentTime + 1.5)
  }

  const refNotes = [
    { n: 'C4', f: 261.63 }, { n: 'D4', f: 293.66 }, { n: 'E4', f: 329.63 },
    { n: 'F4', f: 349.23 }, { n: 'G4', f: 392.00 }, { n: 'A4', f: 440.00 },
    { n: 'B4', f: 493.88 }, { n: 'C5', f: 523.25 },
  ]

  return (
    <>
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase">Afinador Cromático</h3>
          <button onClick={toggle} className="font-sans font-semibold text-xs px-5 py-2.5 rounded-lg border border-[#00ff88] bg-gradient-to-br from-[#004d29] to-[rgba(0,255,136,0.2)] text-[#00ff88] cursor-pointer transition-all hover:shadow-[0_0_30px_rgba(0,255,136,0.25)] uppercase tracking-[1px]">
            {active ? 'PARAR' : 'INICIAR'}
          </button>
        </div>
        <div className="text-center py-8">
          <div className="font-display text-7xl md:text-8xl font-black text-[#00ff88] neon-glow-strong leading-none transition-all duration-150">{note}</div>
          <div className="font-mono text-xl text-[#8fb8a0] mt-2">{freq}</div>
          <div className="w-full max-w-[400px] h-2 bg-[#111d19] rounded-full mx-auto mt-5 relative overflow-hidden">
            <div className="absolute left-1/2 top-[-4px] -translate-x-1/2 w-0.5 h-[16px] bg-[#00ff88] shadow-[0_0_8px_rgba(0,255,136,0.4)]" />
            <div className="absolute top-0 w-3 h-full bg-[#00ff88] rounded-full shadow-[0_0_12px_rgba(0,255,136,0.4)] transition-all duration-100" style={{ left: `${indicatorPos}%` }} />
          </div>
          <div className="font-mono text-xs text-[#4a7a62] mt-4 tracking-[2px]">{status}</div>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Referência de Notas</h3>
          <div className="flex flex-wrap gap-2 justify-center">
            {refNotes.map(r => (
              <button key={r.n} onClick={() => handlePlayRef(r.f)} className="font-sans font-semibold text-xs px-3 py-1.5 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,255,136,0.03)] text-[#e0f5ea] cursor-pointer transition-all hover:border-[#00ff88] hover:text-[#00ff88]">{r.n}</button>
            ))}
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Configurações</h3>
          <div className="flex flex-col gap-4">
            <div>
              <label className="font-mono text-xs text-[#8fb8a0] block mb-2">AFINAÇÃO PADRÃO</label>
              <select className="w-full font-mono text-sm py-2.5 px-4 rounded-lg border border-[rgba(0,255,136,0.15)] bg-[rgba(0,0,0,0.3)] text-[#e0f5ea] outline-none focus:border-[#00ff88]">
                <option>A4 = 440 Hz (Padrão)</option><option>A4 = 442 Hz</option><option>A4 = 432 Hz</option><option>A4 = 445 Hz</option>
              </select>
            </div>
            <div>
              <label className="font-mono text-xs text-[#8fb8a0] block mb-2">SENSIBILIDADE</label>
              <input type="range" min="1" max="10" defaultValue="5" className="w-full" />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
