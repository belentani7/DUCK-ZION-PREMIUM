'use client'

import { useState } from 'react'

const CHAIN = [
  { icon: '⊕', label: 'EQ', desc: 'Equalização paramétrica ativa' },
  { icon: '≡', label: 'COMP', desc: 'Compressão multibanda ativa' },
  { icon: '◇', label: 'STEREO', desc: 'Stereo Imaging ativo' },
  { icon: '■', label: 'LIMITER', desc: 'Limitador brickwall ativo' },
  { icon: '◈', label: 'DITHER', desc: 'Dithering 24-bit aplicado' },
]

export default function MasteringPage() {
  const [gain, setGain] = useState(-3)
  const [ceil, setCeil] = useState(-1)
  const [loudness, setLoudness] = useState(-14)

  return (
    <>
      <div className="relative rounded-[20px] p-8 text-center overflow-hidden mb-6 border border-[#00ff88] bg-gradient-to-br from-[rgba(0,255,136,0.08)] to-[rgba(0,255,136,0.02)]">
        <div className="absolute inset-0 gema-rotate opacity-30" style={{ background: 'conic-gradient(from 0deg, transparent, rgba(0,255,136,0.4), transparent, transparent)' }} />
        <h2 className="font-display text-2xl md:text-4xl font-black text-[#00ff88] neon-glow-strong tracking-[6px] relative z-10">MASTERIZAÇÃO</h2>
        <p className="font-mono text-sm text-[#8fb8a0] mt-2 tracking-[4px] relative z-10">BELENTANI PARA DUCK — A GEMA #1</p>
      </div>

      <div className="glass rounded-2xl p-6 mb-5">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Cadeia de Masterização</h3>
        <div className="flex items-center justify-center gap-3 flex-wrap py-5">
          {CHAIN.map((c, i) => (
            <span key={i} className="contents">
              <button onClick={() => {}} className="w-[90px] h-[90px] md:w-[100px] md:h-[100px] rounded-2xl border border-[rgba(0,255,136,0.15)] bg-[rgba(13,25,20,0.6)] backdrop-blur-sm flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all hover:border-[#00ff88] hover:shadow-[0_0_20px_rgba(0,255,136,0.4)] hover:-translate-y-1">
                <span className="text-2xl text-[#e0f5ea]">{c.icon}</span>
                <span className="font-mono text-[10px] text-[#8fb8a0] uppercase tracking-[1px]">{c.label}</span>
              </button>
              {i < CHAIN.length - 1 && <span className="text-lg text-[#4a7a62] hidden sm:inline">→</span>}
            </span>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Parâmetros de Saída</h3>
          <div className="flex flex-col gap-5">
            {[
              ['Ganho Master', gain, setGain, 'dB'],
              ['Ceiling', ceil, setCeil, 'dB'],
              ['Loudness Target', loudness, setLoudness, ' LUFS'],
            ].map(([label, val, set, unit]) => (
              <div key={label as string}>
                <div className="flex justify-between mb-2">
                  <span className="font-mono text-xs text-[#8fb8a0]">{label as string}</span>
                  <span className="font-mono text-xs text-[#00ff88]">{val as number}{unit as string}</span>
                </div>
                <input type="range" value={val as number} onChange={e => set(+e.target.value)} min={label === 'Loudness Target' ? -18 : -12} max={label === 'Loudness Target' ? -8 : 0} step={label === 'Loudness Target' ? 0.5 : 0.1} className="w-full" />
              </div>
            ))}
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Sobre a Masterização</h3>
          <div className="font-mono text-sm text-[#8fb8a0] leading-relaxed">
            <p>Todas as produções de Duck passam pelo processo exclusivo de masterização desenvolvido por Belentani.</p><br/>
            <p>O processo utiliza uma cadeia de processamento de nível profissional, com equalização cirúrgica, compressão multibanda e limitação brickwall para garantir que cada faixa soe perfeita em qualquer sistema de reprodução.</p><br/>
            <p className="text-[#00ff88]">A GEMA #1 é o selo de qualidade que certifica que a faixa foi masterizada com os mais altos padrões da indústria.</p>
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-xs font-semibold tracking-widest text-[#00ff88] uppercase mb-4">Formatos de Entrega</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[['WAV', '24bit / 48kHz'], ['FLAC', 'Lossless'], ['MP3', '320 kbps']].map(([f, d]) => (
            <div key={f} className="glass rounded-xl p-5 text-center cursor-pointer transition-all hover:border-[rgba(0,255,136,0.4)]">
              <div className="font-display text-lg font-bold text-[#00ff88]">{f}</div>
              <div className="font-mono text-[11px] text-[#8fb8a0] mt-1">{d}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
