'use client'

import { useState, useCallback } from 'react'
import {
  LayoutDashboard,
  Music,
  Diamond,
  Settings,
  PlayCircle,
  LayoutGrid,
  Zap,
  Mail,
  Info,
} from 'lucide-react'
import { useAppStore, type PageId } from '@/stores/useAppStore'

interface NavItem {
  id: PageId
  label: string
  icon: React.ElementType
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Painel', icon: LayoutDashboard },
  { id: 'tuner', label: 'Afinador', icon: Music },
  { id: 'logo', label: 'Logo', icon: Diamond },
  { id: 'plugins', label: 'Plugins', icon: Settings },
  { id: 'player', label: 'Player', icon: PlayCircle },
  { id: 'portfolio', label: 'Portfólio', icon: LayoutGrid },
  { id: 'mastering', label: 'Masterização', icon: Zap },
  { id: 'contact', label: 'Contato', icon: Mail },
]

export default function Sidebar() {
  const currentPage = useAppStore((s) => s.currentPage)
  const setCurrentPage = useAppStore((s) => s.setCurrentPage)
  const incrementEasterEgg = useAppStore((s) => s.incrementEasterEgg)
  const easterEggCount = useAppStore((s) => s.easterEggCount)

  const [logoClicks, setLogoClicks] = useState(0)

  const handleLogoClick = useCallback(() => {
    const next = logoClicks + 1
    setLogoClicks(next)
    if (next === 7 && easterEggCount < 5) {
      incrementEasterEgg()
      setLogoClicks(0)
    }
  }, [logoClicks, easterEggCount, incrementEasterEgg])

  return (
    <nav className="group w-[72px] h-screen glass-strong flex flex-col items-center py-3 transition-all duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] overflow-hidden shrink-0 relative z-[100] hover:w-[240px]">
      {/* Logo */}
      <button
        onClick={handleLogoClick}
        className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#004d29] to-[#111d19] border border-[rgba(0,255,136,0.15)] flex items-center justify-center font-display font-black text-lg text-[#00ff88] neon-glow mb-5 cursor-pointer transition-all duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)] shrink-0 hover:border-[#00ff88] hover:shadow-[0_0_20px_rgba(0,255,136,0.4)]"
      >
        D
      </button>

      {/* Navigation */}
      <div className="flex flex-col gap-1 w-full px-3 flex-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon
          const isActive = currentPage === item.id

          return (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`relative flex items-center gap-3.5 py-3 px-3 rounded-[10px] cursor-pointer transition-all duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)] whitespace-nowrap overflow-hidden ${
                isActive
                  ? 'bg-[rgba(0,255,136,0.12)] border border-[rgba(0,255,136,0.15)]'
                  : 'hover:bg-[rgba(0,255,136,0.1)] border border-transparent'
              }`}
            >
              {/* Active left border indicator */}
              {isActive && (
                <span className="absolute -left-3 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-[#00ff88] rounded-r-[3px] shadow-[0_0_10px_rgba(0,255,136,0.4)]" />
              )}

              <Icon
                className={`w-5 h-5 shrink-0 ${
                  isActive ? 'text-[#00ff88]' : 'text-[#8fb8a0]'
                }`}
              />

              <span
                className={`font-sans text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] ${
                  isActive ? 'text-[#e0f5ea]' : 'text-[#8fb8a0]'
                }`}
              >
                {item.label}
              </span>
            </button>
          )
        })}
      </div>

      {/* Bottom "About" button */}
      <div className="px-3 w-full">
        <button className="relative flex items-center gap-3.5 py-3 px-3 rounded-[10px] cursor-pointer transition-all duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)] whitespace-nowrap overflow-hidden hover:bg-[rgba(0,255,136,0.1)] border border-transparent">
          <Info className="w-5 h-5 shrink-0 text-[#8fb8a0]" />
          <span className="font-sans text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] text-[#8fb8a0]">
            Sobre
          </span>
        </button>
      </div>
    </nav>
  )
}
