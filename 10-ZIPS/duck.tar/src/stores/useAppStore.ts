import { create } from "zustand";

export type PageId =
  | "dashboard"
  | "tuner"
  | "logo"
  | "plugins"
  | "player"
  | "portfolio"
  | "mastering"
  | "contact";

interface AppState {
  currentPage: PageId;
  setCurrentPage: (p: PageId) => void;

  playerTrack: number;
  playerPlaying: boolean;
  playerProgress: number;
  setPlayerTrack: (i: number) => void;
  togglePlay: () => void;
  nextTrack: (total: number) => void;
  prevTrack: (total: number) => void;

  easterEggCount: number;
  secretPanelOpen: boolean;
  matrixActive: boolean;
  incrementEasterEgg: () => void;
  toggleSecretPanel: () => void;
  setMatrixActive: (v: boolean) => void;

  tracks: Array<{ id: string; title: string; artist: string; genre: string; bpm: number; streams: number }>;
  setTracks: (t: AppState["tracks"]) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: "dashboard",
  setCurrentPage: (p) => set({ currentPage: p }),

  playerTrack: 0,
  playerPlaying: false,
  playerProgress: 0,
  setPlayerTrack: (i) => set({ playerTrack: i, playerPlaying: true, playerProgress: 0 }),
  togglePlay: () => set((s) => ({ playerPlaying: !s.playerPlaying })),
  nextTrack: (total) =>
    set((s) => ({ playerTrack: (s.playerTrack + 1) % total, playerProgress: 0 })),
  prevTrack: (total) =>
    set((s) => ({
      playerTrack: (s.playerTrack - 1 + total) % total,
      playerProgress: 0,
    })),

  easterEggCount: 0,
  secretPanelOpen: false,
  matrixActive: false,
  incrementEasterEgg: () => set((s) => ({ easterEggCount: s.easterEggCount + 1 })),
  toggleSecretPanel: () => set((s) => ({ secretPanelOpen: !s.secretPanelOpen })),
  setMatrixActive: (v) => set({ matrixActive: v }),

  tracks: [],
  setTracks: (t) => set({ tracks: t }),
}));
