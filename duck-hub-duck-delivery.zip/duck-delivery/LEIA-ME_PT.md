# Pacote Duck Hub — Protocolo Belentani

Este pacote contém o software Duck Hub, a versão mobile auditada, a documentação em português brasileiro e a simulação vertical 9:16 do Protocolo Belentani.

O vídeo possui duração de 8 segundos e formato vertical 9:16. Ele é uma simulação gráfica de produto: apresenta o remetente identificado, Duck como Guardião da Gema nº 1, o protocolo ativado, o scanner laser e a autorização do usuário.

Abra `duck-hub/docs/ENTREGA_DUCK_PT.md` para entender o que existe, o que é funcional e o que Duck fará ao receber novos clientes, arquivos, revisões, pagamentos ou instruções. Abra `duck-hub/docs/AUDITORIA_MOBILE_PT.md` para a revisão das rotas em 390 × 844 px.
